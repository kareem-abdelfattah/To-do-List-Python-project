import pickle
import datetime

task = []

# Function to load the user dictionary from a file
def load_users():
    try:
        with open('users.txt', 'r') as f:
            lines = f.readlines()
            users = {}
            for line in lines:
                username, password = line.strip().split(',')
                users[username] = password
    except FileNotFoundError:
        users = {}
    return users


# Function to save the user dictionary to a file
def save_users(users):
    with open('users.txt', 'w') as f:
        for username, password in users.items():
            f.write(f"{username},{password}\n")


# Function to register a new user or login with existing credentials
def login_or_register():
    # Load the users dictionary
    users = load_users()

    while True:
        choice = input("Enter 1 to login, 2 to register: ")

        if choice == "1":
            username = input("Enter your username: ")
            password = input("Enter your password: ")

            if username in users and users[username] == password:
                print("Login successful!")
                return username
            else:
                print("Incorrect username or password.")

        elif choice == "2":
            username = input("Choose a username: ")
            password = input("Choose a password: ")

            users[username] = password
            save_users(users)  # Save the updated users dictionary
            print("Registration successful!")
            return username  # Return the username and enter the program

        else:
            print("Invalid choice. Please enter 1 or 2.")


# Call the login_or_register function to get the username
username = login_or_register()

# Welcome the user and display the to-do list
print("Welcome, " + username + "!")


# Function to add a new task
def add():
    # Prompt user to enter task description and deadline
    task_description = input('Add new task: ')
    deadline = input("Enter the deadline of the task (Year-Month-Day Hour:Minute:Second): ")

    # Converting deadline string to datetime object
    the_deadline = datetime.datetime.strptime(deadline, "%Y-%m-%d %H:%M:%S")

    # Adding the task and deadline to the task list
    task.append((task_description, the_deadline))
    print(f"The task: {task_description} with deadline: {the_deadline}.")


def categories():
    task = {}
    while True:
        category = input("Enter category name (or 'E' to Exit): ")
        if category == 'E':
            break
        task_cate = input("Enter task name: ")

        if category in task:
            task[category].append(task_cate)
        else:
            task[category] = [task_cate]

    print("Categories:")
    for category in task:
        print(category)

    print("Tasks:")
    print(task)


# Function to remove a task
def remove():
    # Prompt user to enter task description to remove
    del_task = input("Enter the task you want to remove: ")

    # Looping through the tasks to find and remove the desired task
    for j in task:
        if del_task == j[0]:
            task.remove(j)
            print(f"The task '{del_task}' has been removed.")
            break
    else:
        print("No matching task was found.")


# Function to display all tasks
def display():
    # Looping through the task list to display all tasks
    for idx, t in enumerate(task, start=1):
        task_description = t[0]
        deadline = t[1]
        is_done = t[2] if len(t) > 2 else False  # Check if task status is provided

        mark = "[X]" if is_done else "[ ]"  # Use [X] for done tasks and [ ] for pending tasks
        print(f"{idx} - {mark} {task_description} - Deadline: {deadline}")

# Function to change an existing task
def change():
    # Prompt user to enter task description to update
    old_task = input("Enter the task you want to update: ")

    # Looping through the tasks to find and update the desired task
    for i in range(len(task)):
        if task[i][0] == old_task:
            new_task = input("Enter your new task: ")
            # Enter your new task
            task[i] = (new_task, task[i][1])
            print(f"The task '{old_task}' has been updated to '{new_task}'.")
            break
    else:
        print("No matching task was found.")


# Function to mark a task as done
def done_tasks():
    # Prompt user to enter task description to mark as done
    task_description = input("Enter the task you want to mark as done: ")

    # Looping through the tasks to find and mark the desired tas1k as done
    for i in range(len(task)):
        if task[i][0] == task_description:
            task[i] = (task[i][0], task[i][1], True)
            print(f"The task '{task_description}' has been marked as done.")
            break
    else:
        print("No matching task was found.")


# Function to save the task list to a file
def save_tasks():
    with open('tasks.pickle', 'wb') as f:
         pickle.dump(task, f)


# Load the previously saved tasks from the 'tasks.txt' file or return an empty list if the file does not exist.
def load_tasks():
    try:
        with open('tasks.pickle', 'rb') as f:
            tasks = pickle.load(f)
    except FileNotFoundError:
        tasks = []

    return tasks


# Main function that runs the program and presents the user with a menu to choose from.
def main():
    # Load the tasks from the file
    task.extend(load_tasks())

    while True:
        print("""Choose one:
        1. Add task
        2. Delete task
        3. Display tasks
        4. Change task
        5. Mark as Done
        6. Categories 
        7. Save and exit
            """)
        choice = input('Enter your choice: ')
        if choice == '1':
            add()
        elif choice == '2':
            remove()
        elif choice == '3':
            display()
        elif choice == '4':
            change()
        elif choice == '5':
            done_tasks()
        elif choice == '6':
            categories()
        elif choice == '7':
            save_tasks()
            print('Tasks saved. Good luck!')
            break
        else:
            print('Invalid choice')


if __name__ == '__main__':
    main()
